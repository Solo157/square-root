package com.square.root;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SquareRootApplication {

	public static void main(String[] args) {
		SpringApplication.run(SquareRootApplication.class, args);
	}

}
